import React from 'react'
import './App.css';
import Whether from "./components/Whether"

function App() {
  return (
    <>
   <Whether />
   
    </>
  );
}

export default App;
